
import java.util.Arrays;

public class FourthSmallestElement {
    public static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("List has less than four elements");
            return -1; 
        }

        Arrays.sort(arr);

        return arr[3]; 
    }

    public static void main(String[] args) {
        int[] myList = {9, 3, 7, 1, 5, 10, 6, 2, 4, 8};

        int fourthSmallest = findFourthSmallest(myList);

        if (fourthSmallest != -1) {
            System.out.println("The fourth smallest element is: " + fourthSmallest);
        }
    }
}